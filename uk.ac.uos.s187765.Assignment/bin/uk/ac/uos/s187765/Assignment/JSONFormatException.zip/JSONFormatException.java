package uk.ac.uos.s187765.Assignment;

public class JSONFormatException extends Exception {

	public JSONFormatException(String string) {
		super(string);
	}

}
